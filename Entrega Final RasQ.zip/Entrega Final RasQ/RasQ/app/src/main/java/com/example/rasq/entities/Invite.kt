package com.example.rasq.entities

class Invite(val invitedPhoneNum: String, val eventIndex: Int) : java.io.Serializable
{

}