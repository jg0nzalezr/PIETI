package com.example.rasq.entities

class Bid(
    var price: Int = 0,
    var bidderEmail: String = ""
) : java.io.Serializable {
    // Rest of the class code
}

