import java.io.IOException
import java.io.ObjectInputStream
import java.io.ObjectOutputStream
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

class Payment(
    var date: String = "NO PAYMENT")
 : java.io.Serializable {
    // Rest of the class code

}
